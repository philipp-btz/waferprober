# The velox Python library does not support incomming SCI
# Commands at this time. To implement incomming command functionality, 
# see the examples for C++ and C# in the Vlox Integration Toolkit.
