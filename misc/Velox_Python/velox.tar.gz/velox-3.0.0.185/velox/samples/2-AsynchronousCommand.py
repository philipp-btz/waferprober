# Asyncronous commands require the user to implement async Python routines
# There is no special support for asynchronous commands biult in to the 
# velox Python libraries.
